﻿using System.Configuration;
using System.Data;
using System.Windows;
using DrivingCertificateApp.Views;

namespace DrivingCertificateApp
{
    public partial class App : Application
    {
    }

}
