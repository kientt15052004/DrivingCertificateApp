-- Tạo Database
CREATE DATABASE PRN_PROJECTtest;
GO
USE PRN_PROJECTtest;
GO

-- Bảng Users
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    Role NVARCHAR(50) NOT NULL CHECK (Role IN ('Student', 'Teacher', 'TrafficPolice', 'Admin')),
    Class NVARCHAR(50) NULL,
    School NVARCHAR(100) NULL,
    Phone NVARCHAR(15) NULL
);

-- Bảng Courses
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY IDENTITY(1,1),
    CourseName NVARCHAR(100) NOT NULL,
    TeacherID INT NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    FOREIGN KEY (TeacherID) REFERENCES Users(UserID)
);

-- Bảng Registrations
CREATE TABLE Registrations (
    RegistrationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    CourseID INT NOT NULL,
    Status NVARCHAR(50) DEFAULT 'Waiting',
    Comments NVARCHAR(max) NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);

-- Bảng Exams
CREATE TABLE Exams (
    ExamID INT PRIMARY KEY IDENTITY(1,1),
    CourseID INT NOT NULL,
    Date DATE NOT NULL,
    Room NVARCHAR(50) NOT NULL,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);

-- Bảng Results
CREATE TABLE Results (
    ResultID INT PRIMARY KEY IDENTITY(1,1),
    ExamID INT NOT NULL,
    UserID INT NOT NULL,
    Score DECIMAL(5,2) NOT NULL,
    PassStatus BIT NOT NULL,
    FOREIGN KEY (ExamID) REFERENCES Exams(ExamID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Bảng Certificates
CREATE TABLE Certificates (
    CertificateID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    IssuedDate DATE NOT NULL,
    ExpirationDate DATE NOT NULL,
    CertificateCode NVARCHAR(50) UNIQUE,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Bảng Notifications
CREATE TABLE Notifications (
    NotificationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    Message NVARCHAR(max) NOT NULL,
    SentDate DATETIME DEFAULT GETDATE(),
    IsRead BIT DEFAULT 0,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Dữ liệu mẫu cho Users
INSERT INTO Users (FullName, Email, Password, Role, Class, School, Phone) VALUES
(N'Nguyễn Học Sinh', 'hsnguyen@email.com', 'password123', 'Student', '12A1', N'Trường THPT A', '0987654321'),
(N'Phan Giáo Viên', 'gvphan@email.com', 'password456', 'Teacher', NULL, NULL, '0912345678'),
(N'Trần Cảnh Sát', 'cstran@email.com', 'password789', 'TrafficPolice', NULL, NULL, '0909123456'),
(N'Trần Trung Kiên', 'tktran@email.com', 'password123', 'TrafficPolice', NULL, NULL, '0128343621'),

('Admin User', 'admin@email.com', 'admin123', 'Admin', NULL, NULL, '0999888777');


-- Dữ liệu mẫu cho Courses
INSERT INTO Courses (CourseName, TeacherID, StartDate, EndDate) VALUES
(N'Khóa học lái máy bay', 2, '2025-05-29', '2025-09-30'),
(N'Khóa học lái xe an toàn 101', 2, '2025-04-01', '2025-06-30'),
(N'Khóa học lái xe nâng cao', 2, '2025-07-01', '2025-09-30');

-- Dữ liệu mẫu cho Registrations
INSERT INTO Registrations (UserID, CourseID, Status, Comments) VALUES
(1, 1, 'Approved', N'Đã được duyệt'),
(1, 2, 'Pending', N'Chờ xác nhận');

-- Dữ liệu mẫu cho Exams
INSERT INTO Exams (CourseID, Date, Room) VALUES
(1, '2025-06-30', N'Phòng A1'),
(2, '2025-09-30', N'Phòng B2');

-- Dữ liệu mẫu cho Results
INSERT INTO Results (ExamID, UserID, Score, PassStatus) VALUES
(1, 1, 85, 1);

-- Dữ liệu mẫu cho Certificates
INSERT INTO Certificates (UserID, IssuedDate, ExpirationDate, CertificateCode) VALUES
(1, '2025-07-01', '2030-07-01', 'CERT123456');

-- Dữ liệu mẫu cho Notifications
INSERT INTO Notifications (UserID, Message, SentDate, IsRead) VALUES
(1, N'Bạn đã đăng ký thành công khóa học lái xe an toàn.', GETDATE(), 0),
(1, N'Kết quả thi của bạn: Đạt.', GETDATE(), 0);

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Messenger](
	[MessageID] [int] IDENTITY(1,1) NOT NULL,
	[SenderID] [int] NOT NULL,
	[ReceiverID] [int] NOT NULL,
	[Content] [nvarchar](255) NOT NULL,
	[SentDate] [datetime] NOT NULL,
	[IsRead] [bit] NOT NULL,
	[Status] [nvarchar](20) NOT NULL,
 CONSTRAINT [PK_Messenger] PRIMARY KEY CLUSTERED 
(
	[MessageID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Question]    Script Date: 3/29/2025 4:26:57 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Question](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Text] [nvarchar](300) NULL,
	[Option_1] [nvarchar](500) NULL,
	[Option_2] [nvarchar](500) NULL,
	[Option_3] [nvarchar](500) NULL,
	[Option_4] [nvarchar](500) NULL,
	[CorrectAnswer] [int] NULL,
	[Image] [nvarchar](500) NULL,
 CONSTRAINT [PK_Question] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Messenger] ON 
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (0, 1, 1, N'444', CAST(N'2025-03-26T05:54:22.943' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (1, 2, 2, N'hello', CAST(N'2025-03-26T06:21:23.927' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (2, 1, 2, N'hello123', CAST(N'2025-03-26T06:36:26.493' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (3, 1, 2, N'e chào cô ạ', CAST(N'2025-03-26T06:40:29.473' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (4, 1, 2, N'hello cô', CAST(N'2025-03-26T15:15:39.037' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (5, 2, 2, N'cô chào em', CAST(N'2025-03-26T15:16:29.827' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (6, 1, 2, N'hello cô', CAST(N'2025-03-26T15:53:00.963' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (7, 2, 2, N'Hello e', CAST(N'2025-03-26T15:56:27.497' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (8, 1, 2, N'hi', CAST(N'2025-03-27T08:41:29.693' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (9, 1, 2, N'hi', CAST(N'2025-03-27T08:59:17.940' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (10, 1, 2, N'hi', CAST(N'2025-03-27T09:00:28.880' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (11, 2, 2, N'cô đây', CAST(N'2025-03-27T09:05:56.303' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (12, 1, 2, N'ok', CAST(N'2025-03-27T09:14:50.720' AS DateTime), 0, N'Sent')
GO
INSERT [dbo].[Messenger] ([MessageID], [SenderID], [ReceiverID], [Content], [SentDate], [IsRead], [Status]) VALUES (13, 1, 2, N'okie', CAST(N'2025-03-27T22:12:47.360' AS DateTime), 0, N'Sent')
GO
SET IDENTITY_INSERT [dbo].[Messenger] OFF
GO
SET IDENTITY_INSERT [dbo].[Question] ON 
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (1, N'Người điều khiển phương tiện giao thông đường bộ mà trong cơ thể có chất ma túy có bị nghiêm cấm hay không?', N'Bị nghiêm cấm', N'Không bị nghiêm cấm', N'Không bị nghiêm cấm, nếu có chất ma túy ở mức nhẹ, có thể điều khiển phương tiện tham gia giao thông.', NULL, 0, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (2, N'Hành vi điều khiển xe cơ giới chạy quá tốc độ quy định, giành đường, vượt ẩu có bị nghiêm cấm hay không?', N'Bị nghiêm cấm tùy từng trường hợp', N'Không bị nghiêm cấm', N'Bị nghiêm cấm.', NULL, 2, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (3, N'Bạn đang lái xe phía trước có một xe cứu thương đang phát tín hiệu ưu tiên bạn có được phép vượt hay không?', N'Không được vượt', N'Được vượt khi đang đi trên cầu', N'Được phép vượt khi đi qua nơi giao nhau có ít phương tiện cùng tham gia giao thông', N'Được vượt khi đảm bảo an toàn.', 0, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (4, N'Người điều khiển xe mô tô hai bánh, ba bánh, xe gắn máy có được phép sử dụng xe để kéo hoặc đẩy các phương tiện khác khi tham gia giao thông không?', N'Được phép', N'Nếu phương tiện được kéo, đẩy có khối lượng nhỏ hơn phương tiện của mình', N'Tùy trường hợp', N'Không được phép.', 3, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (5, N'Khi đang lên dốc người ngồi trên xe mô tô có được kéo theo người đang điều khiển xe đạp hay không?', N'Chỉ được phép nếu cả hai đội mũ bảo hiểm

', N' Không được phép', N'NULLChỉ được phép thực hiện trên đường thật vắng', N'Chỉ được phép khi người đi xe đạp đã quá mệt.', 1, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (6, N'Phần của đường bộ đươc sử dụng cho các phương tiện giao thông qua lại là gì?', N'Phần mặt đường và lề đường', N'Phần đường xe chạy', N'Phần đường xe cơ giới.', NULL, 1, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (7, N' “Làn đường” là gì?', N'Là một phần của phần đường xe chạy được chia theo chiều dọc của đường, sử dụng cho xe chạy.', N'Là một phần của phần đường xe chạy được chia theo chiều dọc của đường, có bề rộng đủ cho xe chạy an toàn', N'Là đường cho xe ô tô chạy, dừng, đỗ an toàn.', NULL, 1, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (8, N'Người lái xe được hiểu như thế nào trong các khái niệm dưới đây?', N'Là người điều khiển xe cơ giới', N'Là người điều khiển xe thô sơ', N'Là người điều khiển xe có súc vật kéo.', NULL, 0, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (9, N'Theo luật giao thông đường bộ, tín hiệu đèn giao thông gồm 3 màu nào dưới đây?', N' Đỏ – Vàng – Xanh', N'Cam – Vàng – Xanh', N'Vàng – Xanh dương – Xanh lá', N'Đỏ – Cam – Xanh.', 0, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (10, N'Biển báo hiệu có dạng hình tam giác đều, viền đỏ, nền màu vàng, trên có hình vẽ màu đen là loại biển gì dưới đây?', N'Biển báo nguy hiểm', N'Biển báo cấm', N'Biển báo hiệu lệnh', N'Biển báo chỉ dẫn.', 0, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-44-trong-bo-de-200-cau-hoi-thi-xe-gan-may-a1.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (11, N'NULLBiển báo hiệu hình tròn có nền xanh lam có hình vẽ màu trắng là loại gì dưới đây?', N'Biển báo nguy hiểm', N'Biển báo cấm', N'Biển báo hiệu lệnh phải thi hành', N'Biển báo chỉ dẫn.', 0, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-45-trong-bo-de-200-cau-hoi-thi-lai-xe-may.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (12, N'Biển báo hiệu hình chữ nhật hoặc hình vuông hoặc hình mũi tên nền xanh lam là loại biển gì dưới đây?', N'Biển báo nguy hiểm', N'Biển báo cấm', N'Biển báo hiệu lệnh phải thi hành', N'Biển báo chỉ dẫn.', 2, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-46-trong-bo-de-200-cau-ly-thuyet-thi-lai-xe.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (13, N'Trên đường có nhiều làn đường cho xe đi cùng chiều được phân biệt bằng vạch kẻ phân làn đường, người điều khiển phương tiện phải cho xe đi như thế nào?', N'Cho xe đi trên bất kỳ làn đường nào hoặc giữa 02 làn đường nếu không có xe phía trước; khi cần thiết phải chuyển làn đường, người lái xe phải quan sát xe phía trước để đảm bảo an toàn', N'Phải cho xe đi trong một làn đường và chỉ được chuyển làn đường ở những nơi cho phép; khi chuyển làn phải có tín hiệu báo trước và phải bảo đảm an toàn.', N'Phải cho xe đi trong một làn đường, khi cần thiết phải chuyển làn đường, người lái xe phải quan sát xe phía trước để bảo đảm an toàn.', NULL, 1, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (14, N'Bạn đang lái xe trong khu vực đô thị từ 22 giờ đến 5 giờ sáng hôm sau và cần vượt một xe khác, bạn cần báo hiệu như thế nào để đảm bảo an toàn giao thông?', N'Phải báo hiệu bằng đèn hoặc còi', N'Chỉ được báo hiệu bằng còi', N' Phải báo hiệu bằng cả còi và đèn', N'Chỉ được báo hiệu bằng đèn.', 3, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (15, N' Người lái xe phải giảm tốc độ thấp hơn tốc độ tối đa cho phép (có thể dừng lại một cách an toàn) trong trường hợp nào dưới đây?', N'Khi có báo hiệu cảnh báo nguy hiểm hoặc có chướng ngại vật trên đường; khi chuyển hướng xe chạy hoặc tầm nhìn bị hạn chế; khi qua nơi đường giao nhau, nơi đường bộ giao nhau với đường sắt; đường vòng; đường có địa hình quanh co, đèo dốc.', N'Khi qua cầu, cống hẹp; khi lên gần đỉnh dốc, khi xuống dốc, khi qua trường học, khu đông dân cư, khu vực đang thi công trên đường bộ; hiện trường xảy ra tai nạn giao thông.', N'Khi điều khiển xe vượt xe khác trên đường quốc lộ, đường cao tốc', N'Cả ý 1 và ý 2.', 3, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (16, N'Tại nơi đường giao nhau, người lái xe đang đi trên đường không ưu tiên phải xử lý như thế nào là đúng quy tắc giao thông?', N'Tăng tốc độ qua đường giao nhau để đi trước xe đi trên đường ưu tiên', N'Giảm tốc độ qua đường giao nhau để đi trước xe đi trên đường ưu tiên', N'Nhường đường cho xe đi trên đường ưu tiên hoặc từ bất kỳ hướng nào tới.', NULL, 2, NULL)
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (17, N'Biển nào báo hiệu “Đường giao nhau” của các tuyến đường cùng cấp?', N'Biển 1.', N'Biển 2.', N'Biển 3.', NULL, 0, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-101-trong-bo-de-200-cau-ly-thuyet-a1.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (18, N'Biển nào báo hiệu “Giao nhau với đường không ưu tiên”?', N'Biển 1.', N'Biển 2.', N'Biển 3.', N'Biển 2 và 3.', 0, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-102-trog-bo-de-200-cau-hoi-ly-thuyet-a1.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (19, N'Biển nào báo hiệu sắp đến chỗ giao nhau nguy hiểm?', N' Biển 1.', N'Biển 1 và 2.', N'Biển 2 và 3.', N'Cả ba biển.', 3, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-105-bo-de-200-cau.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (20, N'Biển nào báo hiệu nguy hiểm giao nhau với đường sắt?', N'Biển 1 và 2.', N'Biển 1 và 3.', N'Biển 2 và 3.', N'Cả ba biển.', 1, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-108-bo-de-200-cau-hoi.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (21, N'khi gặp biển nào thì xe mô tô hai bánh được đi vào?', N'Không biển nào.', N'Biển 1 và 2.', N'Biển 2 và 3.', N'Cả 3 biển.', 2, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-124-trong-200-cau-hoi.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (22, N'Các xe đi như thế nào là đúng quy tắc giao thông?', N'Các xe phía tay phải và tay trái của người điều khiển được phép đi thẳng', N'Cho phép các xe ở mọi hướng được rẽ phải', N'Tất cả các xe phải dừng lại trước ngã tư, trừ những xe đã ở trong ngã tư được phép tiếp tục đi.', NULL, 2, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-166.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (23, N'NCác xe đi theo hướng mũi tên, xe nào chấp hành đúng quy tắc giao thông?ULL', N'Xe tải, mô tô', N'Xe khách, mô tô', N'Xe tải, xe con', N'Mô tô, xe con.', 2, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-172.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (24, N' Khi gặp vạch kẻ đường nào các xe được phép đè vạch?', N'Vạch 1', N'Vạch 2', N'Vạch 3', N'Vạch 1 và vạch 3', 3, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-164.jpg')
GO
INSERT [dbo].[Question] ([Id], [Text], [Option_1], [Option_2], [Option_3], [Option_4], [CorrectAnswer], [Image]) VALUES (25, N'Các xe đi theo thứ tự nào là đúng quy tắc giao thông đường bộ?', N'Xe của bạn, mô tô, xe con', N'Xe con, xe của bạn, mô tô', N'Mô tô, xe con, xe của bạn.', NULL, 2, N'https://truongdaotaolaixehcm.com/wp-content/uploads/2020/08/cau-180.jpg')
GO
SET IDENTITY_INSERT [dbo].[Question] OFF
GO
ALTER TABLE [dbo].[Messenger]  WITH CHECK ADD  CONSTRAINT [FK_Messenger_Users] FOREIGN KEY([SenderID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Messenger] CHECK CONSTRAINT [FK_Messenger_Users]
GO
ALTER TABLE [dbo].[Messenger]  WITH CHECK ADD  CONSTRAINT [FK_Messenger_Users1] FOREIGN KEY([ReceiverID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Messenger] CHECK CONSTRAINT [FK_Messenger_Users1]
GO

