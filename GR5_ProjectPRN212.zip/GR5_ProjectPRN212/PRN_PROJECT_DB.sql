-- Tạo Database
--CREATE DATABASE PRN_PROJECT;
--GO
--USE PRN_PROJECT;
--GO

-- Bảng Users
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    Role NVARCHAR(50) NOT NULL CHECK (Role IN ('Student', 'Teacher', 'TrafficPolice', 'Admin')),
    Class NVARCHAR(50) NULL,
    School NVARCHAR(100) NULL,
    Phone NVARCHAR(15) NULL
);

-- Bảng Courses
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY IDENTITY(1,1),
    CourseName NVARCHAR(100) NOT NULL,
    TeacherID INT NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    FOREIGN KEY (TeacherID) REFERENCES Users(UserID)
);

-- Bảng Registrations
CREATE TABLE Registrations (
    RegistrationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    CourseID INT NOT NULL,
    Status NVARCHAR(50) DEFAULT 'Waiting',
    Comments TEXT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);

-- Bảng Exams
CREATE TABLE Exams (
    ExamID INT PRIMARY KEY IDENTITY(1,1),
    CourseID INT NOT NULL,
    Date DATE NOT NULL,
    Room NVARCHAR(50) NOT NULL,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);

-- Bảng Results
CREATE TABLE Results (
    ResultID INT PRIMARY KEY IDENTITY(1,1),
    ExamID INT NOT NULL,
    UserID INT NOT NULL,
    Score DECIMAL(5,2) NOT NULL,
    PassStatus BIT NOT NULL,
    FOREIGN KEY (ExamID) REFERENCES Exams(ExamID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Bảng Certificates
CREATE TABLE Certificates (
    CertificateID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    IssuedDate DATE NOT NULL,
    ExpirationDate DATE NOT NULL,
    CertificateCode NVARCHAR(50) UNIQUE,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Bảng Notifications
CREATE TABLE Notifications (
    NotificationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    Message TEXT NOT NULL,
    SentDate DATETIME DEFAULT GETDATE(),
    IsRead BIT DEFAULT 0,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Dữ liệu mẫu cho Users
INSERT INTO Users (FullName, Email, Password, Role, Class, School, Phone) VALUES
(N'Nguyễn Học Sinh', 'hsnguyen@email.com', 'password123', 'Student', '12A1', N'Trường THPT A', '0987654321'),
(N'Phan Giáo Viên', 'gvphan@email.com', 'password456', 'Teacher', NULL, NULL, '0912345678'),
(N'Trần Cảnh Sát', 'cstran@email.com', 'password789', 'TrafficPolice', NULL, NULL, '0909123456'),
(N'Trần Trung Kiên', 'tktran@email.com', 'password123', 'TrafficPolice', NULL, NULL, '0128343621'),
('Admin User', 'admin@email.com', 'admin123', 'Admin', NULL, NULL, '0999888777');


-- Dữ liệu mẫu cho Courses
INSERT INTO Courses (CourseName, TeacherID, StartDate, EndDate) VALUES
(N'Khóa học lái máy bay', 2, '2025-05-29', '2025-09-30'),
(N'Khóa học lái xe an toàn 101', 2, '2025-04-01', '2025-06-30'),
(N'Khóa học lái xe nâng cao', 2, '2025-07-01', '2025-09-30');

-- Dữ liệu mẫu cho Registrations
INSERT INTO Registrations (UserID, CourseID, Status, Comments) VALUES
(5, 4, 'Pending', N'Chờ xác nhận'),
(1, 1, 'Approved', N'Đã được duyệt'),
(1, 2, 'Pending', N'Chờ xác nhận');

-- Dữ liệu mẫu cho Exams
INSERT INTO Exams (CourseID, Date, Room) VALUES
(1, '2025-06-30', N'Phòng A1'),
(2, '2025-09-30', N'Phòng B2');

-- Dữ liệu mẫu cho Results
INSERT INTO Results (ExamID, UserID, Score, PassStatus) VALUES
(1, 1, 85.5, 1);

-- Dữ liệu mẫu cho Certificates
INSERT INTO Certificates (UserID, IssuedDate, ExpirationDate, CertificateCode) VALUES
(1, '2025-07-01', '2030-07-01', 'CERT123456');

-- Dữ liệu mẫu cho Notifications
INSERT INTO Notifications (UserID, Message, SentDate, IsRead) VALUES
(1, N'Bạn đã đăng ký thành công khóa học lái xe an toàn.', GETDATE(), 0),
(1, N'Kết quả thi của bạn: Đạt.', GETDATE(), 0);
